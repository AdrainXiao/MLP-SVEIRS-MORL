"""Train the MLP-SVEIRS model."""
import json
import math
import os
import sys
import time
import torch

from mlp_sveirs import (
    MLPSVEIRSConfig,
    MLPSVEIRSModel,
    PreparedData,
    compute_loss,
    set_seed,
)
from mlp_sveirs.paths import (
    PRIMARY_INPUT_DIR,
    MLP_SVEIRS_RUNS_DIR,
    resolve_project_path,
)


def main() -> None:
    """Train the model and save the final weights."""
    set_seed(0)
    device = torch.device("cpu")
    torch.set_num_threads(
        max(1, int(os.environ.get("ODE_THREADS", os.cpu_count() or 8)))
    )
    input_dir = (
        resolve_project_path(os.environ["ODE_INPUT_DIR"])
        if os.environ.get("ODE_INPUT_DIR")
        else PRIMARY_INPUT_DIR
    )

    if len(sys.argv) > 3:
        raise SystemExit("Usage: python -m mlp_sveirs.cli.train_ode [epochs] [run_name]")
    epochs = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    run_name = sys.argv[2] if len(sys.argv) > 2 else "ode_generative"
    # Log interval.
    LOG_EVERY = max(1, epochs // 50)

    run_dir = MLP_SVEIRS_RUNS_DIR / run_name
    run_dir.mkdir(parents=True, exist_ok=True)
    log_path = run_dir / "training_log.txt"


    def log(msg: str) -> None:
            line = f"[{time.strftime('%H:%M:%S')}] {msg}"
            print(line, flush=True)
            with open(log_path, "a") as fh:
                fh.write(line + "\n")


    config = MLPSVEIRSConfig(
        # Architecture.
        use_seasonal_features=True,
        seasonal_harmonics=3,
        param_activations=("sine", "tanh"),
        sine_omega0=1.0,
        # Beta prior.
        beta_log_prior_std=0.5,
        lambda_beta_prior=0.02,
        # Regularization.
        lambda_smooth=2.5,
        lambda_h_smooth=0.5,
        lambda_beta_drift=100.0,
        initial_immune_fraction=0.30,
        # Observation weights.
        lambda_ili=1.0,
        lambda_hospital=2.0,
        # Vaccine coverage weight.
        lambda_cum_vaccine=0.1,
        h_log_ref=0.02,
    )
    peak_lr = 2e-3
    data = PreparedData(input_dir, device, config)
    batch = data.make_grid()
    config.model_time_start = float(batch.time_week.min())
    config.model_time_end = float(batch.time_week.max())
    model = MLPSVEIRSModel(data.n_regions, config).to(device)

    with open(run_dir / "config.json", "w") as fh:
        json.dump({**config.__dict__, "epochs": epochs}, fh, indent=2, default=str)
    log(f"lambda_cum_vaccine={config.lambda_cum_vaccine} "
        f"lambda_ili={config.lambda_ili} "
        f"lambda_hospital={config.lambda_hospital} "
        f"lambda_h_smooth={config.lambda_h_smooth} "
        f"h_log_ref={config.h_log_ref}")
    log(f"input_dir={input_dir}")
    with open(run_dir / "arch.json", "w") as fh:
        json.dump(
            {
                "use_seasonal_features": config.use_seasonal_features,
                "seasonal_harmonics": config.seasonal_harmonics,
                "param_activations": list(config.param_activations),
                "sine_omega0": config.sine_omega0,
                "beta_log_prior_std": config.beta_log_prior_std,
                "h_log_ref": config.h_log_ref,
                "hidden_dims": list(config.hidden_dims),
            },
            fh,
            indent=2,
        )
    log(
        f"weeks={batch.n_time} regions={batch.n_regions} "
        f"method=rk4 step_size=0.5 epochs={epochs}"
    )

    # Learning-rate schedule.
    lr_warmup = max(1, int(0.10 * epochs))


    def lr_at(epoch: int) -> float:
        if epoch < lr_warmup:
            return peak_lr * (epoch + 1) / lr_warmup
        progress = (epoch - lr_warmup) / max(1, epochs - lr_warmup)
        return 1e-6 + 0.5 * (peak_lr - 1e-6) * (1.0 + math.cos(math.pi * progress))


    optimizer = torch.optim.Adam(model.parameters(), lr=peak_lr)
    t_start = time.time()
    for epoch in range(1, epochs + 1):
        for group in optimizer.param_groups:
            group["lr"] = lr_at(epoch - 1)
        loss = compute_loss(model, batch, config)
        total = loss["total"]
        if not torch.isfinite(total):
            log(f"ep{epoch:5d} NON-FINITE total={float(total)} -> skip update")
            optimizer.zero_grad()
            continue
        optimizer.zero_grad()
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if epoch % LOG_EVERY == 0 or epoch == 1:
            log(
                f"ep{epoch:5d} lr={optimizer.param_groups[0]['lr']:.2e} "
                f"total={float(loss['total']):9.3f} "
                f"ili={float(loss['ili_input_mse']):8.3f} "
                f"hosp={float(loss['hospital_input_mse']):8.3f} "
                f"cum={float(loss['cum_ili']):8.3f} "
                f"cov={float(loss['cum_vaccine']):8.3f} "
                f"hs={float(loss['h_smooth']):7.4f} "
                f"beta={float(loss['mean_beta']):.3f} "
                f"h={float(loss['mean_h_arg']):.4f} "
                f"inc={float(loss['mean_incidence']):10.1f} "
                f"[{time.time()-t_start:.0f}s]"
            )

    torch.save(model.state_dict(), run_dir / "model_final.pt")
    log(f"DONE total {time.time()-t_start:.0f}s -> {run_dir}")


if __name__ == "__main__":
    main()
