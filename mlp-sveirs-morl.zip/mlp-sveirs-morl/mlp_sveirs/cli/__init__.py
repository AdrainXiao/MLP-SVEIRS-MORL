"""Command-line entry points for MLP-SVEIRS."""
