"""Training loss."""

from __future__ import annotations

import torch
from torch import Tensor

from .config import MLPSVEIRSConfig
from .dataset import GridBatch
from .dynamics import integrate_state
from .model import MLPSVEIRSModel


def masked_mse(
    prediction: Tensor,
    target: Tensor,
    mask: Tensor,
    noise_std: Tensor | None = None,
) -> Tensor:
    """Return masked mean squared error."""
    valid = mask > 0.5
    if not bool(valid.any()):
        return torch.zeros((), device=prediction.device)
    squared = (prediction[valid] - target[valid]) ** 2
    if noise_std is None:
        return squared.mean()
    # Gaussian negative log-likelihood.
    return (squared / (2.0 * noise_std.square()) + torch.log(noise_std)).mean()


def smoothness_loss(
    values: Tensor,
    time_week: Tensor,
    pair_mask: Tensor,
) -> Tensor:
    """Return temporal smoothness loss."""
    if values.shape[0] < 2:
        return torch.zeros((), device=values.device)
    delta_time = time_week[1:] - time_week[:-1]
    valid = (delta_time > 0.5) & (delta_time < 1.5)
    valid = valid & pair_mask.bool()
    if not bool(valid.any()):
        return torch.zeros((), device=values.device)
    delta = values[1:] - values[:-1]
    return delta[valid].square().mean()


def _season_cumsum(values: Tensor, season_starts: Tensor) -> Tensor:
    """Return within-season cumulative sums."""
    if values.shape[0] == 0:
        return values
    running = values.cumsum(dim=0)
    if season_starts.numel() == 0:
        return running
    # Running total before each season start.
    prev = torch.cat(
        [torch.zeros(1, *values.shape[1:], device=values.device, dtype=values.dtype), running[:-1]]
    )
    base_at_start = prev[season_starts]
    t = torch.arange(values.shape[0], device=values.device)
    season_id = torch.searchsorted(season_starts, t, right=True) - 1
    season_id = season_id.clamp_min(0)
    return running - base_at_start[season_id]


def _season_anchor(values: Tensor, season_starts: Tensor) -> Tensor:
    """Return each season's first-row value."""
    if values.shape[0] == 0 or season_starts.numel() == 0:
        return torch.zeros_like(values)
    t = torch.arange(values.shape[0], device=values.device)
    season_id = (torch.searchsorted(season_starts, t, right=True) - 1).clamp_min(0)
    return values[season_starts][season_id]


def compute_loss(
    model: MLPSVEIRSModel,
    batch: GridBatch,
    config: MLPSVEIRSConfig,
) -> dict[str, Tensor]:
    # Weekly model time.
    time = batch.time.detach().clone().requires_grad_(True)
    reference_population = batch.population.reshape(batch.n_time, batch.n_regions)
    physical = model.physical_parameters()
    # Network parameters.
    parameters = model.parameter_forward(
        time,
        batch.region_index,
        batch.weeks.repeat_interleave(batch.n_regions).to(time.dtype),
        physical=physical,
    )
    parameters = {
        key: value.reshape(batch.n_time, batch.n_regions)
        for key, value in parameters.items()
    }
    vaccine_susceptibility_seed = batch.fixed_vaccine_susceptibility.reshape(batch.n_time, 1)
    # Hospitalization field.
    h_field = parameters["h"].reshape(batch.n_time, batch.n_regions)
    hospitalization_rate_ode = h_field
    state = integrate_state(
        parameters["beta"],
        parameters["psi"],
        physical,
        batch.migration_rate,
        reference_population,
        batch.time_week,
        batch.initial_state_fixed,
        vaccine_susceptibility_seed,
        hospitalization_rate_ode,
    )
    population = state.sum(dim=-1).clamp_min(1.0)
    susceptible, exposed, infectious, _, _, vaccinated = state.unbind(dim=-1)
    beta = parameters["beta"]
    psi = parameters["psi"]
    infectious_fraction = infectious / population.clamp_min(1.0)
    force = beta * infectious_fraction.clamp_min(0.0)
    vaccination_flow = psi * susceptible
    vaccine_susceptibility = batch.fixed_vaccine_susceptibility.reshape(-1, 1)
    breakthrough_flow = vaccine_susceptibility * force * vaccinated

    sigma = physical["sigma"]
    hospitalization_rate = h_field
    # Cumulative infection loss.
    weekly_new_infection = force * susceptible + breakthrough_flow
    dt = torch.ones_like(weekly_new_infection)
    dt[1:] = (batch.time_week[1:] - batch.time_week[:-1]).clamp_min(0.0).unsqueeze(-1)
    modeled_cumulative = (weekly_new_infection * dt).cumsum(dim=0)
    cum_ili_loss = masked_mse(
        torch.log1p(modeled_cumulative.clamp_min(0.0)),
        torch.log1p(batch.cum_ili_input.reshape(batch.n_time, batch.n_regions).clamp_min(0.0)),
        batch.ili_mask,
    )
    # Population losses.
    global_population_residual = (
        population.sum(dim=-1) - population[0].sum()
    ) / reference_population.sum(dim=-1).clamp_min(1.0)
    population_global_loss = global_population_residual.square().mean()
    population_reference_loss = (
        (population - reference_population)
        / reference_population.clamp_min(1.0)
    ).square().mean()

    # Observation losses.
    ili_flow = (sigma * exposed).clamp_min(0.0)
    hospital_flow = hospitalization_rate * infectious
    obs_noise = physical["obs_noise"]
    ili_loss = masked_mse(
        torch.log1p(ili_flow),
        batch.ili_input_log1p,
        batch.ili_mask,
        noise_std=obs_noise[0],
    )
    hospital_loss = masked_mse(
        torch.log1p(hospital_flow),
        batch.hospital_input_log1p,
        batch.hospital_mask,
        noise_std=obs_noise[1],
    )
    population_initial_loss = (
        (population[0] - reference_population[0])
        / reference_population[0].clamp_min(1.0)
    ).square().mean()
    # Cumulative vaccination coverage.
    cov_target = batch.vaccine_coverage.reshape(batch.n_time, batch.n_regions)
    cov_target_rel = cov_target - _season_anchor(cov_target, batch.season_starts)
    dt_cov = torch.ones_like(vaccination_flow)
    dt_cov[1:] = (batch.time_week[1:] - batch.time_week[:-1]).clamp_min(0.0).unsqueeze(-1)
    dt_cov[batch.season_starts] = 0.0
    modeled_cov_cum = _season_cumsum(
        vaccination_flow * dt_cov, batch.season_starts
    ) / reference_population.clamp_min(1.0)
    cum_vaccine_loss = masked_mse(
        100.0 * modeled_cov_cum.clamp_min(0.0),
        100.0 * cov_target_rel.clamp_min(0.0),
        batch.vaccine_coverage_mask,
    )
    # Log-R0 prior.
    beta_prior_loss = (
        parameters["beta_log_u"] / max(config.beta_log_prior_std, 1e-3)
    ).square().mean()

    # Mean effective reproduction number.
    beta_log_u = parameters["beta_log_u"]
    theta_t = vaccine_susceptibility.reshape(batch.n_time, -1)
    effective_susceptible = (susceptible + theta_t * vaccinated) / population.clamp_min(1.0)
    r_eff = torch.exp(beta_log_u) * effective_susceptible
    beta_drift_loss = (r_eff.mean(dim=0) - 1.0).square().mean()
    smooth_loss = (
        smoothness_loss(beta, batch.time_week, batch.same_season_pair)
        + smoothness_loss(psi, batch.time_week, batch.same_season_pair)
    )
    # Hospitalization smoothness.
    h_smooth_loss = smoothness_loss(
        h_field, batch.time_week, batch.same_season_pair
    )
    total = (
        config.lambda_ili * ili_loss
        + config.lambda_hospital * hospital_loss
        + config.lambda_population_global * population_global_loss
        + config.lambda_population_reference * population_reference_loss
        + config.lambda_population_initial * population_initial_loss
        + config.lambda_cum_ili * cum_ili_loss
        + config.lambda_cum_vaccine * cum_vaccine_loss
        + config.lambda_smooth * smooth_loss
        + config.lambda_h_smooth * h_smooth_loss
        + config.lambda_beta_prior * beta_prior_loss
        + config.lambda_beta_drift * beta_drift_loss
    )
    return {
        "total": total,
        "ili_input_mse": ili_loss,
        "hospital_input_mse": hospital_loss,
        "population_global": population_global_loss,
        "population_reference": population_reference_loss,
        "population_initial": population_initial_loss,
        "cum_vaccine": cum_vaccine_loss,
        "smooth": smooth_loss,
        "h_smooth": h_smooth_loss,
        "beta_prior": beta_prior_loss,
        "beta_drift": beta_drift_loss,
        "cum_ili": cum_ili_loss,
        "mean_incidence": ili_flow.mean(),
        "mean_beta": beta.mean(),
        "mean_h_arg": h_field.mean(),
    }
