"""Random seeding and positive parameter scaling."""

from __future__ import annotations

import random

import numpy as np
import torch
from torch import Tensor


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def exp_scale(raw: Tensor, reference: float) -> Tensor:
    """Return ``reference * exp(raw)``."""
    return float(reference) * torch.exp(raw)
