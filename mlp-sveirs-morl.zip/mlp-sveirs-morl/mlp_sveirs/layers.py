"""Neural network layers."""

from __future__ import annotations

from typing import Iterable

import torch
from torch import Tensor, nn
from torch.nn import functional as F


class LearnedParameter(nn.Module):
    """Single learnable tensor stored as ``mu``."""

    def __init__(self, shape: tuple[int, ...], init_value: float) -> None:
        super().__init__()
        self.mu = nn.Parameter(torch.full(shape, float(init_value)))

    def value(self) -> Tensor:
        return self.mu


class Linear(nn.Module):
    """Affine layer with ``weight_mu`` and ``bias_mu`` parameters."""

    def __init__(self, in_features: int, out_features: int) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        nn.init.xavier_uniform_(self.weight_mu)
        nn.init.zeros_(self.bias_mu)

    def forward(self, x: Tensor) -> Tensor:
        return F.linear(x, self.weight_mu, self.bias_mu)


class MLP(nn.Module):
    """Multi-layer perceptron."""

    def __init__(
        self,
        in_features: int,
        hidden_dims: Iterable[int],
        out_features: int,
        activations: Iterable[str],
        sine_omega0: float = 1.0,
    ) -> None:
        super().__init__()
        hidden_dims = list(hidden_dims)
        dims = [in_features, *hidden_dims, out_features]
        self.layers = nn.ModuleList(
            [
                Linear(dims[index], dims[index + 1])
                for index in range(len(dims) - 1)
            ]
        )
        n_hidden = len(hidden_dims)
        names = list(activations)
        names = [names[i % len(names)] for i in range(n_hidden)]
        self.activation_names = names
        self.sine_omega0 = float(sine_omega0)

    def _activate(self, name: str, x: Tensor) -> Tensor:
        if name == "tanh":
            return torch.tanh(x)
        if name == "sine":
            return torch.sin(self.sine_omega0 * x)
        raise ValueError(f"unknown activation '{name}'")

    def forward(self, x: Tensor) -> Tensor:
        for name, layer in zip(self.activation_names, self.layers[:-1]):
            x = self._activate(name, layer(x))
        return self.layers[-1](x)
