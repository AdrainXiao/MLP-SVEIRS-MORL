"""Preprocessed weekly data and grid batches."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch import Tensor

from .config import MLPSVEIRSConfig


@dataclass
class GridBatch:
    """Weekly tensors used by the loss."""

    time: Tensor
    time_week: Tensor
    region_index: Tensor
    population: Tensor
    ili_input_count: Tensor
    ili_input_log1p: Tensor
    ili_mask: Tensor
    cum_ili_input: Tensor
    hospital_input_count: Tensor
    hospital_input_log1p: Tensor
    hospital_mask: Tensor
    vaccine_weekly_count: Tensor
    # Vaccine coverage and mask.
    vaccine_coverage: Tensor
    vaccine_coverage_mask: Tensor
    fixed_vaccine_susceptibility: Tensor
    migration_rate: Tensor
    weeks: Tensor
    season_index: Tensor
    same_season_pair: Tensor
    season_starts: Tensor
    initial_state_fixed: Tensor

    @property
    def n_time(self) -> int:
        return int(self.time_week.shape[0])

    @property
    def n_regions(self) -> int:
        return int(self.population.numel() // max(self.n_time, 1))


class PreparedData:
    """Load preprocessed NPZ files into torch tensors."""

    def __init__(self, input_dir: Path, device: torch.device, config: MLPSVEIRSConfig) -> None:
        input_dir = Path(input_dir)
        input_npz = np.load(input_dir / "mlp_sveirs_input.npz")
        migration_npz = np.load(input_dir / "migration_matrices.npz")
        self.states = [str(value) for value in input_npz["states"].tolist()]
        self.years = input_npz["years"].astype(np.int64)
        self.weeks = input_npz["weeks"].astype(np.int64)
        self.season_labels = self.years - (self.weeks < 40).astype(np.int64)
        season_to_index = {
            int(label): index
            for index, label in enumerate(sorted(np.unique(self.season_labels)))
        }
        self.season_index = np.asarray(
            [season_to_index[int(label)] for label in self.season_labels],
            dtype=np.int64,
        )
        self.time_week = input_npz["time_week"].astype(np.float32)
        self.population = input_npz["population"].astype(np.float32)
        self.ili_input_count = input_npz["ili_input_count"].astype(np.float32)
        self.ili_input_log1p = input_npz["ili_input_log1p"].astype(np.float32)
        self.ili_mask = input_npz["ili_observed_mask"].astype(np.float32)
        self.ili_cumulative_count = input_npz["ili_cumulative_count"].astype(np.float32)
        self.hospital_input_count = input_npz["hospital_input_count"].astype(np.float32)
        self.hospital_input_log1p = input_npz["hospital_input_log1p"].astype(np.float32)
        self.hospital_mask = input_npz["hospital_input_mask"].astype(np.float32)
        self.vaccine_coverage = input_npz["vaccine_coverage"].astype(np.float32)
        self.vaccine_weekly_count = input_npz["vaccine_weekly_count"].astype(np.float32)
        # Coverage imputation mask.
        imputed = input_npz["vaccine_coverage_imputed_mask"].astype(np.float32)
        # Valid observed coverage weights.
        self.vaccine_coverage_mask = (
            np.isfinite(self.vaccine_coverage) & (imputed <= 0.5)
        ).astype(np.float32)
        self.migration_years = migration_npz["migration_years"].astype(np.int64)
        raw_migration = migration_npz["M_directed_daily"].astype(np.float32)
        year_to_index = {int(year): index for index, year in enumerate(self.migration_years)}
        migration_indices = np.asarray([year_to_index[int(year)] for year in self.years])
        # Convert daily migration to weekly rates.
        migration = raw_migration[migration_indices] * float(config.migration_rate_scale)
        self.migration_rate = migration.astype(np.float32)
        self.device = device
        self.n_time = len(self.years)
        self.n_regions = len(self.states)
        self.config = config

    def _fixed_initial_state(self, indices: np.ndarray) -> Tensor:
        """Return the initial compartment counts."""
        first = int(indices[0])
        population = torch.as_tensor(self.population[first], dtype=torch.float32)
        infectious = torch.as_tensor(
            self.ili_input_count[first], dtype=torch.float32
        ).nan_to_num(0.0)
        # Convert observed ILI flow to exposed stock.
        sigma_seed = float(self.config.sigma_fixed)
        exposed_scale = 1.0 / max(sigma_seed, 1e-6)
        if first >= 2:
            exposed = torch.as_tensor(
                self.ili_input_count[first - 2], dtype=torch.float32
            ).nan_to_num(0.0) * exposed_scale
        else:
            exposed = infectious.clone() * exposed_scale
        hospital = torch.as_tensor(
            self.hospital_input_count[first], dtype=torch.float32
        ).nan_to_num(0.0)
        vaccinated = torch.as_tensor(
            self.vaccine_weekly_count[first], dtype=torch.float32
        ).nan_to_num(0.0)
        # Initial immune population.
        recovered = float(self.config.initial_immune_fraction) * population
        non_susceptible = exposed + infectious + hospital + recovered + vaccinated
        scale = torch.minimum(
            torch.ones_like(non_susceptible),
            0.95 * population / non_susceptible.clamp_min(1.0),
        )
        exposed = exposed * scale
        infectious = infectious * scale
        hospital = hospital * scale
        recovered = recovered * scale
        vaccinated = vaccinated * scale
        susceptible = population - exposed - infectious - hospital - recovered - vaccinated
        return torch.stack(
            [susceptible, exposed, infectious, hospital, recovered, vaccinated], dim=-1
        ).to(self.device)

    def make_grid(self) -> GridBatch:
        """Build the weekly training grid."""
        indices = np.arange(self.n_time)
        time_week = torch.as_tensor(self.time_week[indices], device=self.device)
        region = torch.arange(self.n_regions, device=self.device).repeat(len(indices))
        flat_time = time_week.repeat_interleave(self.n_regions)
        flat_population = torch.as_tensor(self.population[indices], device=self.device).reshape(-1)
        selected_seasons = self.season_index[indices]
        selected_labels = self.season_labels[indices]
        missing = sorted(
            {int(label) for label in selected_labels}
            - set(self.config.season_vaccine_effectiveness)
        )
        if missing:
            raise ValueError(f"No CDC vaccine effectiveness entry for seasons {missing}.")
        fixed_vaccine_susceptibility = torch.as_tensor(
            [1.0 - self.config.season_vaccine_effectiveness[int(label)] / 100.0 for label in selected_labels],
            device=self.device,
            dtype=torch.float32,
        )
        same_season_pair = selected_seasons[1:] == selected_seasons[:-1]
        season_change = np.concatenate(
            ([True], selected_seasons[1:] != selected_seasons[:-1])
        )
        season_starts = torch.as_tensor(
            np.flatnonzero(season_change), device=self.device, dtype=torch.long
        )
        return GridBatch(
            time=flat_time,
            time_week=time_week,
            region_index=region,
            population=flat_population,
            ili_input_count=torch.as_tensor(
                self.ili_input_count[indices], device=self.device
            ),
            ili_input_log1p=torch.as_tensor(
                self.ili_input_log1p[indices], device=self.device
            ),
            ili_mask=torch.as_tensor(self.ili_mask[indices], device=self.device),
            cum_ili_input=torch.as_tensor(
                self.ili_cumulative_count[indices], device=self.device
            ),
            hospital_input_count=torch.as_tensor(
                self.hospital_input_count[indices], device=self.device
            ),
            hospital_input_log1p=torch.as_tensor(
                self.hospital_input_log1p[indices], device=self.device
            ),
            hospital_mask=torch.as_tensor(self.hospital_mask[indices], device=self.device),
            vaccine_weekly_count=torch.as_tensor(
                self.vaccine_weekly_count[indices], device=self.device
            ),
            vaccine_coverage=torch.as_tensor(
                self.vaccine_coverage[indices], device=self.device
            ),
            vaccine_coverage_mask=torch.as_tensor(
                self.vaccine_coverage_mask[indices], device=self.device
            ),
            fixed_vaccine_susceptibility=fixed_vaccine_susceptibility,
            migration_rate=torch.as_tensor(
                self.migration_rate[indices], device=self.device
            ),
            weeks=torch.as_tensor(self.weeks[indices], device=self.device),
            season_index=torch.as_tensor(
                selected_seasons, device=self.device, dtype=torch.long
            ),
            same_season_pair=torch.as_tensor(
                same_season_pair, device=self.device
            ),
            season_starts=season_starts,
            initial_state_fixed=self._fixed_initial_state(indices),
        )

