"""MLP-SVEIRS parameter network."""

from __future__ import annotations

import torch
from torch import Tensor, nn

from .config import MLPSVEIRSConfig
from .layers import LearnedParameter, MLP
from .numerics import exp_scale


class MLPSVEIRSModel(nn.Module):
    """Parameter network for MLP-SVEIRS."""

    def __init__(
        self,
        n_regions: int,
        config: MLPSVEIRSConfig,
    ) -> None:
        super().__init__()
        self.n_regions = n_regions
        self.config = config
        network_input_dim = 1
        self.seasonal_dim = (
            2 * config.seasonal_harmonics if config.use_seasonal_features else 0
        )
        # Three output heads: beta, psi and h.
        n_heads = 3
        network_output_dim = n_heads * n_regions
        self.parameter_net = MLP(
            network_input_dim + self.seasonal_dim,
            config.hidden_dims,
            network_output_dim,
            activations=config.param_activations,
            sine_omega0=config.sine_omega0,
        )
        # Zero output head initialization.
        last = self.parameter_net.layers[-1]
        nn.init.zeros_(last.weight_mu)
        nn.init.zeros_(last.bias_mu)

        self.raw_obs_noise = LearnedParameter((2,), 0.0)

    def physical_parameters(self) -> dict[str, Tensor]:
        device = next(self.parameter_net.parameters()).device
        constant = lambda value: torch.full((), float(value), device=device)
        return {
            "sigma": constant(self.config.sigma_fixed),
            "gamma_i": constant(self.config.gamma_i_fixed),
            "gamma_h": constant(self.config.gamma_h_fixed),
            "eta": constant(self.config.eta_fixed),
            "rho_r": constant(self.config.rho_r_fixed),
            "obs_noise": exp_scale(self.raw_obs_noise.value(), self.config.obs_noise_init),
        }

    def _features(self, time: Tensor) -> Tensor:
        time_input = (
            (time.reshape(-1, 1) - self.config.model_time_start)
            / (self.config.model_time_end - self.config.model_time_start)
        )
        return time_input

    def _seasonal_features(self, week_of_year: Tensor) -> Tensor:
        """Return annual Fourier features."""
        phase = 2.0 * torch.pi * week_of_year.reshape(-1, 1) / 52.18
        harmonics = torch.arange(
            1, self.config.seasonal_harmonics + 1, device=phase.device, dtype=phase.dtype
        )
        angle = phase * harmonics
        return torch.cat([torch.sin(angle), torch.cos(angle)], dim=1)

    def parameter_forward(
        self,
        time: Tensor,
        region_index: Tensor,
        week_of_year: Tensor,
        physical: dict[str, Tensor],
    ) -> dict[str, Tensor]:
        """Return beta, psi and h fields."""
        features = self._features(time)
        if self.seasonal_dim > 0:
            features = torch.cat([features, self._seasonal_features(week_of_year)], dim=1)
        raw = self.parameter_net(features)
        n_reg = self.n_regions
        idx = region_index.long().unsqueeze(1)
        beta_raw = raw.gather(1, idx).squeeze(1)
        psi_raw = raw.gather(1, idx + n_reg).squeeze(1)
        h_raw = raw.gather(1, idx + 2 * n_reg).squeeze(1)
        psi = float(self.config.psi_init) * torch.exp(psi_raw)
        h_field = self.config.h_log_ref * torch.exp(h_raw)
        beta_log_u = beta_raw
        scale = physical["gamma_i"] + h_field
        beta = scale * torch.exp(beta_log_u)
        return {"beta": beta, "psi": psi, "h": h_field, "beta_log_u": beta_log_u}
