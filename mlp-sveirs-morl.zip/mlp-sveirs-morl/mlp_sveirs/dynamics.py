"""SVEIHRS dynamics and integration."""

from __future__ import annotations

import torch
from torch import Tensor


_MOBILE_MASK_CACHE: dict[tuple, Tensor] = {}
RK4_STEP_SIZE = 0.5


def _mobile_mask(
    like: Tensor,
) -> Tensor:
    """Return the mobile-compartment mask."""
    key = (str(like.device), str(like.dtype))
    mask = _MOBILE_MASK_CACHE.get(key)
    if mask is None:
        mask = torch.zeros(6, dtype=like.dtype, device=like.device)
        mask[[0, 1, 2, 4, 5]] = 1.0
        _MOBILE_MASK_CACHE[key] = mask
    return mask


def migration_flux(
    migration_rate: Tensor,
    state_fraction: Tensor,
    reference_population: Tensor,
) -> Tensor:
    """Return weekly inter-region migration derivatives."""
    reference_population = reference_population.clamp_min(1.0)
    mobile_mask = _mobile_mask(state_fraction)
    mobile_fraction = state_fraction * mobile_mask
    state_share = mobile_fraction / mobile_fraction.sum(
        dim=-1,
        keepdim=True,
    ).clamp_min(1e-6)
    weekly_flow = migration_rate * reference_population.unsqueeze(-2)
    destination_inflow = weekly_flow @ state_share
    source_outflow = weekly_flow.sum(dim=-2).unsqueeze(-1) * state_share
    return destination_inflow - source_outflow


def sveihrs_rhs_counts(
    state: Tensor,
    beta_w: Tensor,
    psi_w: Tensor,
    physical: dict[str, Tensor],
    migration_rate_w: Tensor,
    reference_pop_w: Tensor,
    vaccine_susceptibility_w: Tensor,
    hospitalization_rate: Tensor,
) -> Tensor:
    """Return the SVEIHRS right-hand side."""
    population = state.sum(dim=-1).clamp_min(1.0)
    fraction = state / population.unsqueeze(-1)
    susceptible, exposed, infectious, hospital, recovered, vaccinated = state.unbind(
        dim=-1
    )
    force = beta_w * infectious / population
    infection_flow = force * susceptible
    breakthrough = vaccine_susceptibility_w * force * vaccinated
    vaccination = psi_w * susceptible
    waning = physical["rho_r"] * recovered
    migration = migration_flux(migration_rate_w, fraction, reference_pop_w)
    sigma = physical["sigma"]
    gamma_i = physical["gamma_i"]
    gamma_h = physical["gamma_h"]
    eta = physical["eta"]
    exposed_flow = sigma * exposed
    recovery_flow = gamma_i * infectious
    discharge_flow = gamma_h * hospital
    hospitalization_flow = hospitalization_rate * infectious
    protected_flow = eta * vaccinated
    derivatives = torch.stack(
        [
            -infection_flow - vaccination + protected_flow + waning,
            infection_flow + breakthrough - exposed_flow,
            exposed_flow - recovery_flow - hospitalization_flow,
            hospitalization_flow - discharge_flow,
            recovery_flow + discharge_flow - waning,
            vaccination - protected_flow - breakthrough,
        ],
        dim=-1,
    )
    return derivatives + migration


def _interpolate_tables(
    fields: dict[str, Tensor],
    time_week: Tensor,
    step_size: float,
) -> dict[str, Tensor]:
    """Interpolate weekly fields onto the RK4 grid."""
    (beta,) = (fields["beta"],)
    n_time = beta.shape[0]
    if n_time < 2:
        raise ValueError("the ODE grid needs at least two weekly knots")
    t_start = float(time_week[0])
    t_end = float(time_week[-1])
    steps = (t_end - t_start) / step_size
    if abs(steps - round(steps)) > 1e-9:
        raise ValueError("the weekly time grid must be uniform for fixed-step RK4")
    half = 0.5 * step_size
    n_sub = 2 * int(round(steps)) + 1
    grid = (
        torch.arange(n_sub, dtype=time_week.dtype, device=time_week.device) * half
        + t_start
    )
    idx = (torch.searchsorted(time_week, grid, right=True) - 1).clamp(0, n_time - 2)
    nxt = (idx + 1).clamp(0, n_time - 1)
    span = (time_week[nxt] - time_week[idx]).clamp_min(1e-8)
    frac = ((grid - time_week[idx]) / span).clamp(0.0, 1.0)
    tables = {}
    for name, field in fields.items():
        share = frac.reshape((-1,) + (1,) * (field.dim() - 1))
        low = field[idx]
        tables[name] = low + (field[nxt] - low) * share
    tables["_half_step"] = torch.as_tensor(half, dtype=time_week.dtype)
    tables["_t_start"] = torch.as_tensor(t_start, dtype=time_week.dtype)
    tables["_n_sub"] = torch.as_tensor(n_sub, dtype=torch.int64)
    return tables


def integrate_mlp_sveirs(
    beta: Tensor,
    psi: Tensor,
    physical: dict[str, Tensor],
    migration_rate: Tensor,
    reference_population: Tensor,
    time_week: Tensor,
    state0: Tensor,
    vaccine_susceptibility: Tensor,
    hospitalization_rate: Tensor,
) -> Tensor:
    """Integrate the SVEIHRS system with fixed-step RK4."""
    from torchdiffeq import odeint

    tables = _interpolate_tables(
        {
            "beta": beta,
            "psi": psi,
            "migration": migration_rate,
            "population": reference_population,
            "hospitalization": hospitalization_rate,
            "vaccine": vaccine_susceptibility,
        },
        time_week,
        RK4_STEP_SIZE,
    )
    n_sub = int(tables["_n_sub"])
    half_step = float(tables["_half_step"])
    tab_start = float(tables["_t_start"])

    def rhs(t: Tensor, y: Tensor) -> Tensor:
        k = int(round((float(t.reshape(())) - tab_start) / half_step))
        k = min(max(k, 0), n_sub - 1)
        return sveihrs_rhs_counts(
            y.clamp_min(0.0),
            tables["beta"][k],
            tables["psi"][k],
            physical,
            tables["migration"][k],
            tables["population"][k],
            tables["vaccine"][k],
            tables["hospitalization"][k],
        )

    solution = odeint(
        rhs,
        state0,
        time_week,
        method="rk4",
        options={"step_size": RK4_STEP_SIZE},
    )
    return solution.clamp_min(0.0)


def integrate_state(
    beta: Tensor,
    psi: Tensor,
    physical: dict[str, Tensor],
    migration_rate: Tensor,
    reference_population: Tensor,
    time_week: Tensor,
    state0: Tensor,
    vaccine_susceptibility: Tensor,
    hospitalization_rate: Tensor,
) -> Tensor:
    """Integrate the fitted SVEIHRS trajectory."""
    return integrate_mlp_sveirs(
        beta, psi, physical, migration_rate, reference_population,
        time_week, state0, vaccine_susceptibility, hospitalization_rate,
    )
