"""Project path helpers."""

from __future__ import annotations

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PREPROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
MLP_SVEIRS_RUNS_DIR = PROJECT_ROOT / "mlp_sveirs" / "results"

PRIMARY_INPUT_DIR = PREPROCESSED_DIR / "dataset_2010_2019"
DEFAULT_MLP_SVEIRS_RUN = MLP_SVEIRS_RUNS_DIR / "ode_generative"


def resolve_project_path(path: str | Path) -> Path:
    """Resolve a path relative to the project root."""
    candidate = Path(path).expanduser()
    return candidate if candidate.is_absolute() else PROJECT_ROOT / candidate


def relative_to_project(path: str | Path) -> str:
    """Return a project-relative path when possible."""
    candidate = Path(path).expanduser()
    try:
        return str(candidate.resolve().relative_to(PROJECT_ROOT))
    except ValueError:
        return str(candidate)
