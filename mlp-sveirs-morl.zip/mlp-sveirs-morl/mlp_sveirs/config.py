"""MLP-SVEIRS configuration."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class MLPSVEIRSConfig:
    hidden_dims: tuple[int, ...] = (256, 128, 64)
    model_time_start: float = 1.0
    model_time_end: float = 781.0
    migration_rate_scale: float = 7.0
    lambda_ili: float = 1.0
    lambda_hospital: float = 1.0
    lambda_population_global: float = 10.0
    lambda_population_reference: float = 0.10
    lambda_population_initial: float = 10.0
    lambda_smooth: float = 2.5
    lambda_h_smooth: float = 0.5
    lambda_beta_prior: float = 0.005
    beta_log_prior_std: float = 0.5
    psi_init: float = 0.005
    lambda_beta_drift: float = 10.0
    initial_immune_fraction: float = 0.30
    use_seasonal_features: bool = True
    seasonal_harmonics: int = 2
    param_activations: tuple[str, ...] = ("sine", "tanh")
    sine_omega0: float = 1.0
    obs_noise_init: float = 1.0
    lambda_cum_vaccine: float = 0.1
    lambda_cum_ili: float = 1.0
    eta_fixed: float = 1.0 / 26.0
    season_vaccine_effectiveness: dict[int, float] = field(
        default_factory=lambda: {
            2009: 56.0,
            2010: 60.0,
            2011: 47.0,
            2012: 49.0,
            2013: 52.0,
            2014: 19.0,
            2015: 48.0,
            2016: 40.0,
            2017: 38.0,
            2018: 29.0,
            2019: 39.0,
            2021: 36.0,
            2022: 30.0,
            2023: 44.0,
            2024: 56.0,
            2025: 36.0,
        }
    )
    sigma_fixed: float = 3.5
    gamma_i_fixed: float = 1.0
    rho_r_fixed: float = 0.0078
    gamma_h_fixed: float = 1.75
    h_log_ref: float = 0.02
