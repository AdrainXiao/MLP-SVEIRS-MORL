"""Load fitted MLP-SVEIRS runs."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
from torch import Tensor

from .config import MLPSVEIRSConfig
from .dataset import GridBatch, PreparedData
from .dynamics import integrate_state
from .model import MLPSVEIRSModel
from .paths import PRIMARY_INPUT_DIR, PROJECT_ROOT

ARCH_FILENAME = "arch.json"
RUN_CONFIG_FILENAME = "config.json"
CHECKPOINT_FILENAME = "model_final.pt"

class RunArtifactsError(RuntimeError):
    """Invalid run artifacts."""


@dataclass(frozen=True)
class FittedRun:
    """Loaded model, data and grid."""

    model: MLPSVEIRSModel
    config: MLPSVEIRSConfig
    data: PreparedData
    batch: GridBatch

def resolve_input_dir(input_dir: str | Path | None) -> Path:
    """Resolve the input directory."""
    if input_dir is None:
        return PRIMARY_INPUT_DIR
    candidate = Path(input_dir).expanduser()
    return candidate if candidate.is_absolute() else PROJECT_ROOT / candidate


def resolve_run_dir(run_dir: str | Path) -> Path:
    candidate = Path(run_dir).expanduser()
    return candidate if candidate.is_absolute() else PROJECT_ROOT / candidate


def read_run_metadata(run_dir: str | Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Read architecture and run configuration."""
    run_dir = resolve_run_dir(run_dir)
    arch_path = run_dir / ARCH_FILENAME
    config_path = run_dir / RUN_CONFIG_FILENAME
    missing = [path.name for path in (arch_path, config_path) if not path.exists()]
    if missing:
        raise RunArtifactsError(
            f"{run_dir} is missing {', '.join(missing)}"
        )
    return json.loads(arch_path.read_text()), json.loads(config_path.read_text())


def build_mlp_sveirs_config(
    arch: dict[str, Any],
    run_config: dict[str, Any],
) -> MLPSVEIRSConfig:
    """Build the configuration saved with a checkpoint."""
    table = run_config["season_vaccine_effectiveness"]
    season_table = {int(label): float(value) for label, value in table.items()}

    return MLPSVEIRSConfig(
        use_seasonal_features=bool(arch["use_seasonal_features"]),
        seasonal_harmonics=int(arch["seasonal_harmonics"]),
        param_activations=tuple(arch["param_activations"]),
        sine_omega0=float(arch["sine_omega0"]),
        beta_log_prior_std=float(arch["beta_log_prior_std"]),
        h_log_ref=float(arch["h_log_ref"]),
        hidden_dims=tuple(int(dim) for dim in arch.get("hidden_dims", (256, 128, 64))),
        initial_immune_fraction=float(run_config["initial_immune_fraction"]),
        eta_fixed=float(run_config.get("eta_fixed", MLPSVEIRSConfig().eta_fixed)),
        sigma_fixed=float(run_config.get("sigma_fixed", MLPSVEIRSConfig().sigma_fixed)),
        gamma_i_fixed=float(run_config.get("gamma_i_fixed", MLPSVEIRSConfig().gamma_i_fixed)),
        gamma_h_fixed=float(run_config.get("gamma_h_fixed", MLPSVEIRSConfig().gamma_h_fixed)),
        rho_r_fixed=float(run_config.get("rho_r_fixed", MLPSVEIRSConfig().rho_r_fixed)),
        season_vaccine_effectiveness=season_table,
    )


def _load_weights(model: MLPSVEIRSModel, state_dict: dict[str, Any]) -> None:
    """Load checkpoint weights."""
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    if unexpected:
        raise RunArtifactsError(
            f"checkpoint contains keys the model does not use: {sorted(unexpected)[:5]}"
        )
    if missing:
        raise RunArtifactsError(f"checkpoint is missing keys: {sorted(missing)[:5]}")


def load_fitted_run(
    run_dir: str | Path,
    *,
    input_dir: str | Path | None = None,
    device: str | torch.device = "cpu",
) -> FittedRun:
    """Load a fitted model and its data."""
    run_dir = resolve_run_dir(run_dir)
    input_dir = resolve_input_dir(input_dir)
    device = torch.device(device)
    arch, run_config = read_run_metadata(run_dir)
    checkpoint_path = run_dir / CHECKPOINT_FILENAME
    if not checkpoint_path.exists():
        raise RunArtifactsError(f"checkpoint {checkpoint_path} does not exist")
    state_dict = torch.load(checkpoint_path, map_location="cpu")

    config = build_mlp_sveirs_config(
        arch, run_config
    )
    data = PreparedData(input_dir, device, config)
    batch = data.make_grid()
    config.model_time_start = float(batch.time_week.min())
    config.model_time_end = float(batch.time_week.max())

    model = MLPSVEIRSModel(data.n_regions, config).to(device)
    _load_weights(model, state_dict)
    model.eval()
    return FittedRun(
        model=model,
        config=config,
        data=data,
        batch=batch,
    )


@dataclass(frozen=True)
class FittedFields:
    """Fitted fields and trajectory."""

    beta: Tensor
    h: Tensor
    theta: Tensor
    population: Tensor
    migration: Tensor
    weeks: Tensor
    state: Tensor
    physical: dict[str, Tensor]

    def as_dict(self) -> dict[str, Any]:
        """Return fields as a dictionary."""
        return {
            "beta": self.beta,
            "h": self.h,
            "theta": self.theta,
            "pop": self.population,
            "migration": self.migration,
            "weeks": self.weeks,
            "state": self.state,
            "physical": self.physical,
        }


@torch.no_grad()
def evaluate_fitted_fields(
    model: MLPSVEIRSModel,
    batch: GridBatch,
) -> FittedFields:
    """Evaluate fitted fields and integrate the trajectory."""
    n_time, n_regions = batch.n_time, batch.n_regions
    physical = model.physical_parameters()
    parameters = model.parameter_forward(
        batch.time,
        batch.region_index,
        batch.weeks.repeat_interleave(batch.n_regions).to(batch.time.dtype),
        physical=physical,
    )
    beta = parameters["beta"].reshape(n_time, n_regions)
    h_field = parameters["h"].reshape(n_time, n_regions)
    theta = batch.fixed_vaccine_susceptibility.reshape(n_time)
    population = batch.population.reshape(n_time, n_regions)
    state = integrate_state(
        beta,
        parameters["psi"].reshape(n_time, n_regions),
        physical,
        batch.migration_rate,
        population,
        batch.time_week,
        batch.initial_state_fixed,
        theta.reshape(n_time, 1),
        h_field,
    )
    return FittedFields(
        beta=beta,
        h=h_field,
        theta=theta,
        population=population,
        migration=batch.migration_rate,
        weeks=batch.weeks.to(beta.dtype),
        state=state,
        physical=physical,
    )
