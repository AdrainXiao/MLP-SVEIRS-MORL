"""Multi-objective reinforcement learning on the fitted SVEIHRS environment."""
