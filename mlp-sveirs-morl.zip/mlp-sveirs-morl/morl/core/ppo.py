"""PPO policy, rollout and update."""
from __future__ import annotations

from dataclasses import dataclass, field

import torch
import torch.nn as nn
from torch.distributions import Categorical


@dataclass
class PPOConfig:
    total_iterations: int = 60
    gamma: float = 1.0
    gae_lambda: float = 0.95
    clip_ratio: float = 0.2
    lr: float = 3e-4
    epochs: int = 4
    minibatch: int = 256
    entropy_coef: float = 0.0
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    hidden: int = 128
    seed: int = 0
    n_levels: int = 4
    n_dose_levels: int = 4


class ActorCritic(nn.Module):
    """Actor-critic network."""

    def __init__(self, n_regions: int, obs_dim: int, cfg: PPOConfig):
        super().__init__()
        self.obs_dim = obs_dim
        self.n_levels = int(cfg.n_levels)
        self.n_dose_levels = int(cfg.n_dose_levels)
        self.encoder = nn.Sequential(
            nn.Linear(obs_dim, cfg.hidden),
            nn.Tanh(),
            nn.Linear(cfg.hidden, cfg.hidden),
            nn.Tanh(),
        )
        self.dose_head = nn.Linear(cfg.hidden, self.n_dose_levels)
        self.iso_head = nn.Linear(cfg.hidden, self.n_levels)
        self.mask_head = nn.Linear(cfg.hidden, self.n_levels)
        self.critic = nn.Sequential(
            nn.Linear(cfg.hidden, cfg.hidden),
            nn.Tanh(),
            nn.Linear(cfg.hidden, 1),
        )
        for layer in (self.dose_head, self.iso_head, self.mask_head):
            nn.init.orthogonal_(layer.weight, gain=0.01)
            nn.init.zeros_(layer.bias)

    def features(self, obs: torch.Tensor) -> torch.Tensor:
        return self.encoder(obs)

    def forward(self, obs: torch.Tensor):
        feat = self.features(obs)
        dose = self.dose_head(feat)
        iso_logits = self.iso_head(feat)
        mask_logits = self.mask_head(feat)
        value = self.critic(feat.mean(dim=1)).squeeze(-1)
        return dose, iso_logits, mask_logits, value

    @staticmethod
    def _masked_logits(logits: torch.Tensor, mask) -> torch.Tensor:
        return logits.masked_fill(~mask, -1e9)

    def act(self, obs: torch.Tensor, dose_mask, iso_mask, mask_mask,
            deterministic: bool = False):
        dose_out, iso_logits, mask_logits, value = self.forward(obs)
        dose_dist = Categorical(logits=self._masked_logits(dose_out, dose_mask))
        iso_dist = Categorical(logits=self._masked_logits(iso_logits, iso_mask))
        mask_dist = Categorical(logits=self._masked_logits(mask_logits, mask_mask))
        dose_action = (dose_dist.probs.argmax(dim=-1) if deterministic
                       else dose_dist.sample())
        if deterministic:
            iso_level = iso_dist.probs.argmax(dim=-1)
            mask_level = mask_dist.probs.argmax(dim=-1)
        else:
            iso_level = iso_dist.sample()
            mask_level = mask_dist.sample()
        # Joint action log-probability.
        logp = (dose_dist.log_prob(dose_action)
                + iso_dist.log_prob(iso_level)
                + mask_dist.log_prob(mask_level)).sum(-1)
        return {"dose": dose_action, "iso_level": iso_level, "mask_level": mask_level,
                "logp": logp, "value": value}

    def evaluate_actions(self, obs, dose, iso_level, mask_level,
                         dose_mask, iso_mask, mask_mask):
        """Recompute log-probabilities, entropy and values."""
        dose_out, iso_logits, mask_logits, value = self.forward(obs)
        dose_dist = Categorical(logits=self._masked_logits(dose_out, dose_mask))
        iso_dist = Categorical(logits=self._masked_logits(iso_logits, iso_mask))
        mask_dist = Categorical(logits=self._masked_logits(mask_logits, mask_mask))
        logp = (dose_dist.log_prob(dose) + iso_dist.log_prob(iso_level)
                + mask_dist.log_prob(mask_level)).sum(-1)
        entropy = dose_dist.entropy() + iso_dist.entropy() + mask_dist.entropy()
        return logp, entropy, value


@dataclass
class Rollout:
    obs: list = field(default_factory=list)
    dose: list = field(default_factory=list)
    iso_level: list = field(default_factory=list)
    mask_level: list = field(default_factory=list)
    dose_mask: list = field(default_factory=list)
    iso_mask: list = field(default_factory=list)
    mask_mask: list = field(default_factory=list)
    obj: list = field(default_factory=list)
    logp: list = field(default_factory=list)
    value: list = field(default_factory=list)
    reward: list = field(default_factory=list)


def collect_rollout(env, policy, weights, cfg: PPOConfig, reward_scale: float = 1.0):
    """Collect one rollout."""
    obs = env.reset()
    roll = Rollout()
    with torch.no_grad():
        for _ in range(env.T):
            dose_mask, iso_mask, mask_mask = env.level_mask()
            a = policy.act(obs, dose_mask, iso_mask, mask_mask,
                           deterministic=False)
            next_obs, reward, _, _, info = env.step(
                a["dose"], a["iso_level"], a["mask_level"])
            shaped = (reward @ weights) / reward_scale
            roll.obs.append(obs)
            roll.dose.append(a["dose"])
            roll.iso_level.append(a["iso_level"])
            roll.mask_level.append(a["mask_level"])
            roll.dose_mask.append(dose_mask)
            roll.iso_mask.append(iso_mask)
            roll.mask_mask.append(mask_mask)
            roll.logp.append(a["logp"])
            roll.value.append(a["value"])
            roll.reward.append(shaped)
            roll.obj.append(info["raw"])
            obs = next_obs
    return roll


def returns_and_advantages(roll: Rollout, cfg: PPOConfig):
    """Return GAE advantages and returns."""
    gamma = cfg.gamma
    T = len(roll.reward)
    N = roll.reward[0].shape[0]
    rewards = torch.stack(roll.reward, dim=0)   # [T,N]
    values = torch.stack(roll.value, dim=0)     # [T,N]
    adv = torch.zeros_like(rewards)
    last = torch.zeros(N, device=rewards.device, dtype=rewards.dtype)
    for t in reversed(range(T)):
        nonterminal = 1.0 - (1.0 if t == T - 1 else 0.0)
        next_value = values[t + 1] if t + 1 < T else torch.zeros_like(last)
        delta = rewards[t] + gamma * next_value * nonterminal - values[t]
        last = delta + gamma * cfg.gae_lambda * nonterminal * last
        adv[t] = last
    ret = adv + values
    return ret, adv


def ppo_update(policy, optimizer, roll: Rollout, cfg: PPOConfig):
    ret, adv = returns_and_advantages(roll, cfg)
    T = len(roll.reward)
    N = roll.reward[0].shape[0]
    obs = torch.stack(roll.obs, dim=0).reshape(T * N, -1, policy.obs_dim)
    dose = torch.stack(roll.dose, dim=0).reshape(T * N, -1)
    iso_level = torch.stack(roll.iso_level, dim=0).reshape(T * N, -1)
    mask_level = torch.stack(roll.mask_level, dim=0).reshape(T * N, -1)
    dose_mask = torch.stack(roll.dose_mask, dim=0).reshape(
        T * N, -1, policy.n_dose_levels)
    iso_mask = torch.stack(roll.iso_mask, dim=0).reshape(T * N, -1, policy.n_levels)
    mask_mask = torch.stack(roll.mask_mask, dim=0).reshape(T * N, -1, policy.n_levels)
    old_logp = torch.stack(roll.logp, dim=0).reshape(T * N)
    ret = ret.reshape(T * N)
    adv = adv.reshape(T * N)
    adv = (adv - adv.mean()) / (adv.std() + 1e-8)

    stats = {}
    for _ in range(cfg.epochs):
        perm = torch.randperm(T * N, device=obs.device)
        for start in range(0, T * N, cfg.minibatch):
            idx = perm[start:start + cfg.minibatch]
            logp, entropy, value = policy.evaluate_actions(
                obs[idx], dose[idx], iso_level[idx], mask_level[idx],
                dose_mask[idx], iso_mask[idx], mask_mask[idx])
            ratio = torch.exp(logp - old_logp[idx])
            unclipped = ratio * adv[idx]
            clipped = torch.clamp(ratio, 1 - cfg.clip_ratio, 1 + cfg.clip_ratio) * adv[idx]
            policy_loss = -torch.min(unclipped, clipped).mean()
            value_loss = (value - ret[idx]).square().mean()
            entropy = entropy.mean()
            loss = policy_loss + cfg.value_coef * value_loss - cfg.entropy_coef * entropy
            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(policy.parameters(), cfg.max_grad_norm)
            optimizer.step()
            stats = {"policy_loss": float(policy_loss), "value_loss": float(value_loss),
                     "entropy": float(entropy)}
    return stats


class NullPolicy:
    """No-intervention policy."""

    def __init__(self, n_envs: int, n_regions: int, device, dtype):
        self.dose = torch.zeros(n_envs, n_regions, device=device, dtype=dtype)
        self.level = torch.zeros(n_envs, n_regions, device=device, dtype=torch.long)

    def act(self, obs, dose_mask, iso_mask, mask_mask, deterministic=True):
        return {"dose": self.dose, "iso_level": self.level, "mask_level": self.level}


def _regeneration_fields(env, state, q_eff, m_eff):
    """Return R0, R_eff and the NPI factor."""
    idx = min(env.t, env.s.episode_weeks)
    pop = state.sum(-1).clamp_min(1.0)
    S, _E, _I, _H, _R, V = state.unbind(dim=-1)
    beta = env.s.beta[:, idx]
    hosp = env.s.h[:, idx]
    theta = env.s.theta[:, idx].unsqueeze(-1)
    r0 = beta / (float(env.physical["gamma_i"]) + hosp)
    immune = ((S + theta * V) / pop).clamp_min(0.0)
    npi = (1.0 - q_eff) * (1.0 - m_eff)
    return r0, r0 * immune * npi, npi


@torch.no_grad()
def evaluate_policy(policy, env):
    """Evaluate a deterministic policy and return J, C and trajectories."""
    obs = env.reset()
    J = torch.zeros(env.N, 3, device=env.device, dtype=env.dtype)
    C = torch.zeros(env.N, env.N_DIAGNOSTICS, device=env.device, dtype=env.dtype)
    traj = {k: [] for k in ("v", "q", "m", "dose_level", "q_level", "m_level",
                            "d_realised", "I_share", "I_count", "H_share",
                            "V_share", "S_share", "E_share", "R_share",
                            "N_share", "R0", "R_eff", "npi_factor",
                            "calendar_week", "population", "season_index")}
    for t in range(env.T):
        dose_mask, iso_mask, mask_mask = env.level_mask()
        a = policy.act(obs, dose_mask, iso_mask, mask_mask, deterministic=True)
        v, q, m = env.project_action(a["dose"], a["iso_level"], a["mask_level"])
        state_in = env.state
        r0, r_eff, npi = _regeneration_fields(env, state_in, q, m)
        obs, _, cost, _, info = env.step(
            a["dose"], a["iso_level"], a["mask_level"])
        J = J + info["raw"]
        C = C + cost
        pop_in = state_in.sum(-1).clamp_min(1.0)
        traj["S_share"].append(state_in[..., 0] / pop_in)
        traj["E_share"].append(state_in[..., 1] / pop_in)
        traj["R_share"].append(state_in[..., 4] / pop_in)
        traj["N_share"].append(pop_in / env.s.pop[:, min(t, env.s.episode_weeks)])
        traj["R0"].append(r0)
        traj["R_eff"].append(r_eff)
        traj["npi_factor"].append(npi)
        traj["calendar_week"].append(env.s.weeks[:, min(t, env.s.episode_weeks)])
        traj["population"].append(env.s.pop[:, min(t, env.s.episode_weeks)])
        pop = env.state.sum(-1).clamp_min(1.0)
        traj["v"].append(v)
        traj["q"].append(q)
        traj["m"].append(m)
        traj["q_level"].append(a["iso_level"].to(env.dtype))
        traj["m_level"].append(a["mask_level"].to(env.dtype))
        traj["dose_level"].append(a["dose"].to(env.dtype))
        traj["d_realised"].append(env.d_obs.clone())
        traj["I_share"].append(env.state[..., 2] / pop)
        traj["I_count"].append(env.state[..., 2].clone())
        traj["H_share"].append(env.state[..., 3] / pop)
        traj["V_share"].append(env.state[..., 5] / pop)
        traj["season_index"].append(env.s.season_index[:, t].clone())
    traj = {k: torch.stack(v, dim=0).cpu().numpy() for k, v in traj.items()}
    return J, C, traj
