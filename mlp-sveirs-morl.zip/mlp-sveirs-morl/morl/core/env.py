"""Batched counterfactual SVEIHRS environment for multi-objective RL."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

import torch

from mlp_sveirs.fitted_run import evaluate_fitted_fields, load_fitted_run
from mlp_sveirs import migration_flux


OBSERVATION_HISTORY = 4
OBS_PREVALENCE_REF = 1e-4
OBS_HOSPITAL_REF = 5e-6
RK4_SUBSTEPS = 2
VACCINE_WANING_PER_WEEK = 1.0 / 26.0

def load_fitted(
    run_dir: str | Path,
    input_dir: str | Path = "data/processed/dataset_2010_2019",
    device: str | torch.device = "cpu",
):
    """Rebuild the trained model, data and training grid."""
    run = load_fitted_run(
        run_dir,
        input_dir=input_dir,
        device=device,
    )
    return run.model, run.config, run.data, run.batch


@torch.no_grad()
def fitted_fields(model, batch):
    """Return fitted parameter fields and trajectories."""
    return evaluate_fitted_fields(model, batch).as_dict()


@dataclass
class EnvConfig:
    episode_weeks: int = 481
    # NPI tier effects.
    mask_level_effect: tuple = (0.00, 0.05, 0.15, 0.25)
    iso_level_effect: tuple = (0.00, 0.10, 0.30, 0.50)
    # NPI tier prices.
    mask_level_price: tuple = (0.00, 0.10, 0.30, 0.50)
    iso_level_price: tuple = (0.00, 0.20, 0.60, 1.00)
    max_level_step: int = 1
    # Fatigue parameters.
    fatigue_rho: float = 0.95
    fatigue_max_mult: float = 3.0
    # Vaccination tiers.
    d_max_per_capita: float = 0.08
    dose_level_frac: tuple = (0.00, 0.25, 0.625, 1.00)
    # Dose tier prices.
    dose_level_price: tuple = (0.00, 0.30, 0.80, 1.50)
    max_dose_level_step: int = 1
    # Cost coefficients.
    c_mask: float = 0.03
    c_lockdown: float = 2.0
    c_vaccine: float = 1.0
    hospital_capacity_per_capita: float = 2e-4
    # Objective weights.
    lambda_cost: float = 3.4945092e-04
    lambda_diss: float = 1.3121055e+04

    def __post_init__(self):
        if len(self.dose_level_frac) != len(self.dose_level_price):
            raise ValueError("dose_level_frac and dose_level_price must have equal length")
        if any(
            current >= following
            for current, following in zip(self.dose_level_frac, self.dose_level_frac[1:])
        ):
            raise ValueError("dose_level_frac must be strictly increasing")
        for name, eff, price in (("mask", self.mask_level_effect, self.mask_level_price),
                                 ("iso", self.iso_level_effect, self.iso_level_price)):
            if len(eff) != len(price):
                raise ValueError(f"{name} effect and price must have equal length")

    @property
    def n_levels(self) -> int:
        return len(self.mask_level_price)

    @property
    def n_dose_levels(self) -> int:
        return len(self.dose_level_frac)

    @property
    def fatigue_ss(self) -> float:
        """Steady-state fatigue memory."""
        return 1.0 / max(1e-6, 1.0 - self.fatigue_rho)


@dataclass
class Scenario:
    """Batched episode tensors."""

    beta: torch.Tensor        # [N, T+1, R]
    h: torch.Tensor           # [N, T+1, R]
    theta: torch.Tensor       # [N, T+1]
    migration: torch.Tensor   # [N, T+1, R, R]
    pop: torch.Tensor         # [N, T+1, R]
    weeks: torch.Tensor       # [N, T+1]
    season_index: torch.Tensor # [N, T+1]
    state0: torch.Tensor      # [N, R, 6]
    physical: dict = field(default_factory=dict)

    @property
    def episode_weeks(self) -> int:
        return self.beta.shape[1] - 1


def build_scenarios(
    model,
    data,
    batch,
    cfg: EnvConfig,
    n_envs: int = 8,
    device: str | torch.device = "cpu",
) -> Scenario:
    """Build identical counterfactual episodes."""
    device = torch.device(device)
    T_total = batch.n_time
    start = int(batch.season_starts[0])

    fields = fitted_fields(model, batch)
    available = T_total - start - 1
    t_common = min(cfg.episode_weeks, available)
    if t_common < 2:
        raise ValueError(
            f"episode too short ({t_common} weeks): the fitted run has only "
            f"{available} usable weeks; reduce episode_weeks."
        )

    sl = slice(start, start + t_common + 1)
    beta = fields["beta"][sl]
    h = fields["h"][sl]
    theta = fields["theta"][sl]
    migration = fields["migration"][sl]
    population = fields["pop"][sl]
    weeks = fields["weeks"][sl]
    season_index = torch.as_tensor(batch.season_index[sl], device=device)
    state0 = fields["state"][start]

    def batch(x, dtype=torch.float32):
        x = x.to(device=device, dtype=dtype)
        return x.unsqueeze(0).repeat((n_envs,) + (1,) * x.dim())

    return Scenario(
        beta=batch(beta),
        h=batch(h),
        theta=batch(theta),
        migration=batch(migration),
        pop=batch(population),
        weeks=batch(weeks),
        season_index=batch(season_index, dtype=torch.long),
        state0=batch(state0),
        physical=fields["physical"],
    )


class VecSVEIHRSEnv:
    """Batched weekly-step SVEIHRS environment."""

    N_DIAGNOSTICS = 2

    def __init__(self, scenario: Scenario, cfg: EnvConfig):
        self.s = scenario
        self.cfg = cfg
        self.N, self.T, self.R = scenario.beta.shape[0], scenario.episode_weeks, scenario.beta.shape[2]
        self.device = scenario.beta.device
        self.dtype = scenario.beta.dtype
        self.total_pop = scenario.pop[:, 0, :].sum(dim=-1)  # [N]
        self.t = 0
        self.state = scenario.state0.clone()
        # Current tiers.
        self.q_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        self.m_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        # Tier tables.
        self.mask_effect = torch.tensor(cfg.mask_level_effect, device=self.device, dtype=self.dtype)
        self.iso_effect = torch.tensor(cfg.iso_level_effect, device=self.device, dtype=self.dtype)
        self.mask_price = torch.tensor(cfg.mask_level_price, device=self.device, dtype=self.dtype)
        self.iso_price = torch.tensor(cfg.iso_level_price, device=self.device, dtype=self.dtype)
        # Dose tables.
        self.dose_rate = torch.tensor(cfg.dose_level_frac, device=self.device, dtype=self.dtype) * cfg.d_max_per_capita
        self.dose_price = torch.tensor(cfg.dose_level_price, device=self.device, dtype=self.dtype)
        self.dose_lv_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        # Fatigue gains.
        f_ss2 = cfg.fatigue_ss ** 2
        self.fat_mask = (cfg.fatigue_max_mult - 1.0) * float(self.mask_price[-1]) / f_ss2
        self.fat_iso = (cfg.fatigue_max_mult - 1.0) * float(self.iso_price[-1]) / f_ss2
        self.mask_price_strong = max(float(self.mask_price[-1]), 1e-9)
        self.iso_price_strong = max(float(self.iso_price[-1]), 1e-9)
        self.fat_q = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.fat_m = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.d_obs = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.obs_history = OBSERVATION_HISTORY
        self._obs_queue = deque(maxlen=self.obs_history)
        self.set_physical(scenario.physical)
        self.baseline_none = torch.zeros(1, 3, device=self.device, dtype=self.dtype)
        self.baseline_full = torch.ones(1, 3, device=self.device, dtype=self.dtype)
        self.baseline_none = self._rollout_baseline(0, 0, 0)
        self.baseline_full = self._rollout_baseline(
            cfg.n_levels - 1, cfg.n_levels - 1, cfg.n_dose_levels - 1)
        self.reset()

    def _rollout_baseline(self, q_level: int, m_level: int, dose_level: int):
        """Return cumulative objectives for a constant policy."""
        self.reset()
        lv = self.cfg.n_levels - 1
        q_lv = min(max(int(q_level), 0), lv)
        m_lv = min(max(int(m_level), 0), lv)
        total = torch.zeros(self.N, 3, device=self.device, dtype=self.dtype)
        lv_d = min(max(int(dose_level), 0), self.cfg.n_dose_levels - 1)
        first = self.dose_rate[lv_d].expand(self.N, self.R)
        for _ in range(self.T):
            q = torch.full((self.N, self.R), q_lv, device=self.device, dtype=torch.long)
            m = torch.full((self.N, self.R), m_lv, device=self.device, dtype=torch.long)
            dl = torch.full((self.N, self.R), lv_d, device=self.device, dtype=torch.long)
            _, _, _, _, info = self._step_exact(first, q, m, dl)
            total = total + info["raw"]
        return total.mean(dim=0, keepdim=True)

    def reset(self):
        self.t = 0
        self.state = self.s.state0.clone()
        # Start without historical vaccination.
        historical_v = self.state[..., 5].clone()
        self.state[..., 0] = self.state[..., 0] + historical_v
        self.state[..., 5] = 0.0
        self.q_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        self.m_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        self.fat_q = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.fat_m = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.d_obs = torch.zeros(self.N, self.R, device=self.device, dtype=self.dtype)
        self.dose_lv_prev = torch.zeros(self.N, self.R, device=self.device, dtype=torch.long)
        self._obs_queue.clear()
        first_obs = self._obs_frame()
        for _ in range(self.obs_history):
            self._obs_queue.append(first_obs.clone())
        return self.obs()

    def level_mask(self):
        """Return feasible tier masks."""
        cfg = self.cfg

        def _mask(prev, n_lv, step):
            idx = torch.arange(n_lv, device=self.device).reshape(1, 1, -1)
            return (idx - prev.unsqueeze(-1)).abs() <= step

        return (_mask(self.dose_lv_prev, cfg.n_dose_levels,
                      cfg.max_dose_level_step),
                _mask(self.q_prev, cfg.n_levels, cfg.max_level_step),
                _mask(self.m_prev, cfg.n_levels, cfg.max_level_step))

    def project_dose_levels(self, dose_level):
        """Clip the dose tier to the allowed step."""
        cfg = self.cfg
        dose_level = dose_level.long()
        step, hi = cfg.max_dose_level_step, cfg.n_dose_levels - 1
        lv = dose_level.clamp((self.dose_lv_prev - step).clamp_min(0),
                              (self.dose_lv_prev + step).clamp_max(hi))
        return lv

    def project_levels(self, q_level, m_level):
        """Clip NPI tiers to the allowed step."""
        cfg = self.cfg
        q_level = q_level.long()
        m_level = m_level.long()
        step, hi = cfg.max_level_step, cfg.n_levels - 1
        ql = q_level.clamp((self.q_prev - step).clamp_min(0), (self.q_prev + step).clamp_max(hi))
        ml = m_level.clamp((self.m_prev - step).clamp_min(0), (self.m_prev + step).clamp_max(hi))
        return ql, ml

    def project_action(self, dose, q_level, m_level):
        """Project an action and return its realised effects."""
        dl = self.project_dose_levels(dose)
        d = self.dose_rate[dl]
        ql, ml = self.project_levels(q_level, m_level)
        return d, self.iso_effect[ql], self.mask_effect[ml]

    def _deriv(self, state, idx, first, q, m):
        cfg, s = self.cfg, self.s
        pop = state.sum(dim=-1).clamp_min(1.0)
        frac = state / pop.unsqueeze(-1)
        S, E, I, H, Rr, V = state.unbind(dim=-1)
        force = s.beta[:, idx] * I / pop
        npi = (1.0 - m) * (1.0 - q)
        force = force * npi
        breakthrough = s.theta[:, idx].unsqueeze(-1) * force * V
        susceptible = S.clamp_min(0.0)
        d_flow = first.clamp_min(0.0) * pop
        # Cap at susceptible population.
        d_flow = torch.minimum(d_flow, susceptible)
        waning = self.rho_r * Rr
        phys = self.physical
        derivs = torch.stack(
            [
                -force * S - d_flow + self.eta * V + waning,
                force * S + breakthrough - phys["sigma"] * E,
                phys["sigma"] * E - phys["gamma_i"] * I - s.h[:, idx] * I,
                s.h[:, idx] * I - phys["gamma_h"] * H,
                phys["gamma_i"] * I + phys["gamma_h"] * H - waning,
                d_flow - self.eta * V - breakthrough,
            ],
            dim=-1,
        )
        migration = migration_flux(s.migration[:, idx], frac, s.pop[:, idx])
        self._dC = (force * (S + s.theta[:, idx].unsqueeze(-1) * V)).sum(dim=-1)
        self._dH = (s.h[:, idx] * I).sum(dim=-1)
        self._dflow = d_flow
        return derivs + migration

    def step(self, dose, q_level, m_level):
        dl = self.project_dose_levels(dose)
        first = self.dose_rate[dl]
        ql, ml = self.project_levels(q_level, m_level)
        return self._step_exact(first, ql, ml, dl)

    def _step_exact(self, first, q_level, m_level, dose_level):
        """Advance one week."""
        cfg, s = self.cfg, self.s
        q_level, m_level = q_level.long(), m_level.long()
        # Tier effects and prices.
        q, m = self.iso_effect[q_level], self.mask_effect[m_level]
        kap_q, kap_m = self.iso_price[q_level], self.mask_price[m_level]
        dose_level = dose_level.long()
        eff_first, eff_q, eff_m = first, q, m
        idx = min(self.t, s.episode_weeks)
        dt = 1.0 / RK4_SUBSTEPS
        S_before = self.state[..., 0]
        state = self.state
        dC = torch.zeros(self.N, device=self.device, dtype=self.dtype)
        dH = torch.zeros_like(dC)
        dD = torch.zeros_like(self.state[..., 0])
        for _ in range(RK4_SUBSTEPS):
            k1 = self._deriv(state, idx, eff_first, eff_q, eff_m)
            c1, h1 = self._dC, self._dH
            f1 = self._dflow
            k2 = self._deriv(state + 0.5 * dt * k1, idx, eff_first, eff_q, eff_m)
            c2, h2 = self._dC, self._dH
            f2 = self._dflow
            k3 = self._deriv(state + 0.5 * dt * k2, idx, eff_first, eff_q, eff_m)
            c3, h3 = self._dC, self._dH
            f3 = self._dflow
            k4 = self._deriv(state + dt * k3, idx, eff_first, eff_q, eff_m)
            c4, h4 = self._dC, self._dH
            f4 = self._dflow
            state = (state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)).clamp_min(0.0)
            dC = dC + (dt / 6.0) * (c1 + 2 * c2 + 2 * c3 + c4)
            dH = dH + (dt / 6.0) * (h1 + 2 * h2 + 2 * h3 + h4)
            dD = dD + (dt / 6.0) * (f1 + 2 * f2 + 2 * f3 + f4)
        self.state = state
        self.t += 1

        pop = self.s.pop[:, idx].clamp_min(1.0)
        d_dose = torch.minimum(dD, S_before)
        # Update fatigue memory.
        self.fat_q = cfg.fatigue_rho * self.fat_q + kap_q / self.iso_price_strong
        self.fat_m = cfg.fatigue_rho * self.fat_m + kap_m / self.mask_price_strong
        # Intervention cost.
        d_cost = (
            (cfg.c_mask * pop * kap_m + cfg.c_lockdown * pop * kap_q).sum(dim=-1)
            + cfg.c_vaccine * d_dose.sum(dim=-1)
        )
        pop_end = self.state.sum(dim=-1).clamp_min(1.0)
        S_share = self.state[..., 0] / pop_end
        H_share = self.state[..., 3] / pop_end
        V_share = self.state[..., 5] / pop_end
        # Dissatisfaction.
        d_rate_realised = d_dose / pop
        kap_d = self.dose_price[dose_level]
        d_diss = (
            kap_q + kap_m + kap_d
            + self.fat_iso * self.fat_q.square()
            + self.fat_mask * self.fat_m.square()
        ).mean(dim=-1)
        # Health loss.
        d_health = dC + dH

        # Diagnostics.
        churn = (q_level - self.q_prev).abs() + (m_level - self.m_prev).abs()
        norm = max(1, cfg.n_levels - 1)
        churn = churn + (dose_level - self.dose_lv_prev).abs() * norm / max(1, cfg.n_dose_levels - 1)
        smooth = churn.to(self.dtype).mean(dim=-1) / norm
        cap = torch.relu(H_share - cfg.hospital_capacity_per_capita).mean(dim=-1)
        cost = torch.stack([smooth, cap], dim=-1)

        self.q_prev, self.m_prev = q_level, m_level
        self.dose_lv_prev = dose_level
        self.d_obs = d_rate_realised
        raw = torch.stack(
            [d_health, cfg.lambda_cost * d_cost, cfg.lambda_diss * d_diss],
            dim=-1,
        )
        reward = -raw
        done = torch.full((self.N,), self.t >= s.episode_weeks, dtype=torch.bool, device=self.device)
        info = {"S_share": S_share, "H_share": H_share, "V_share": V_share,
                "d_health": d_health, "d_cost": d_cost, "d_diss": d_diss,
                "raw": raw, "components": (dC + dH, d_cost, d_diss)}
        return self.obs(), reward, cost, done, info

    def _obs_frame(self):
        """Return the current observation frame."""
        idx = min(self.t, self.s.episode_weeks)
        state = self.state
        pop = state.sum(dim=-1).clamp_min(1.0)
        _, _, I, H, _, V = state.unbind(dim=-1)
        week = self.s.weeks[:, idx]
        week_frac = (week % 52.0) / 52.0
        prev = (I / pop).clamp_min(1e-12)
        hosp = (H / pop).clamp_min(1e-12)
        lv = max(1, self.cfg.n_levels - 1)
        f_ss = self.cfg.fatigue_ss
        # Episode progress.
        progress = torch.full((self.N, 1), self.t / max(1, self.s.episode_weeks),
                              device=self.device, dtype=self.dtype)
        feats = [
            torch.log10(prev / OBS_PREVALENCE_REF).clamp(-10.0, 10.0),
            torch.log10(hosp / OBS_HOSPITAL_REF).clamp(-10.0, 10.0),
            V / pop,
            self.q_prev.to(self.dtype) / lv,
            self.m_prev.to(self.dtype) / lv,
            self.fat_q / f_ss,
            self.fat_m / f_ss,
            (self.dose_obs_feature()),
            week_frac.unsqueeze(-1).expand(-1, self.R),
            self.s.pop[:, idx] / self.total_pop.unsqueeze(-1),
            progress.expand(-1, self.R),
        ]
        return torch.stack(feats, dim=-1)  # [N, R, 11]

    def dose_obs_feature(self) -> torch.Tensor:
        """Return the normalised dose tier."""
        lv = max(1, self.cfg.n_dose_levels - 1)
        return (self.dose_lv_prev.to(self.dtype) / lv).clamp(0.0, 1.0)

    def obs(self):
        frame = self._obs_frame()
        self._obs_queue.append(frame)
        return torch.cat(list(self._obs_queue), dim=-1)

    @property
    def n_obs_features(self) -> int:
        """Observation width per region."""
        return 11

    @property
    def obs_dim(self) -> int:
        return self.n_obs_features * self.obs_history

    def set_physical(self, physical: dict):
        """Set physical rates and vaccine waning."""
        self.physical = {**physical, "eta": float(VACCINE_WANING_PER_WEEK)}
        self.eta = float(VACCINE_WANING_PER_WEEK)
        self.rho_r = float(physical["rho_r"])
