"""Train PPO policies."""
from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

from mlp_sveirs.paths import DEFAULT_MLP_SVEIRS_RUN, relative_to_project

from .core.env import EnvConfig, VecSVEIHRSEnv, build_scenarios, load_fitted
from .core.ppo import ActorCritic, PPOConfig, collect_rollout, evaluate_policy, ppo_update


def train_one(env: VecSVEIHRSEnv, weights, pcfg: PPOConfig,
              reward_scale: float = 1.0, log=print):
    """Train one preference vector."""
    torch.manual_seed(pcfg.seed)
    policy = ActorCritic(env.R, env.obs_dim, pcfg)
    opt = torch.optim.Adam(policy.parameters(), lr=pcfg.lr)
    hist = []
    for it in range(1, pcfg.total_iterations + 1):
        roll = collect_rollout(env, policy, weights, pcfg,
                               reward_scale=reward_scale)
        stats = ppo_update(policy, opt, roll, pcfg)
        episode_return = float(torch.stack(roll.reward, 0).sum(0).mean())
        J_iter = torch.stack(roll.obj, 0).sum(0).mean(0)
        hist.append({"iter": it, "return": episode_return,
                     "J_raw": [float(x) for x in J_iter], **stats})
        if it % max(1, pcfg.total_iterations // 10) == 0 or it == 1:
            log(f"    it{it:4d} return={episode_return:+.3f} "
                f"J=[{', '.join(f'{float(x):.4g}' for x in J_iter)}] "
                f"pi={stats['policy_loss']:+.3f} v={stats['value_loss']:.3f}")

    J, C, traj = evaluate_policy(policy, env)
    return policy, J, C, traj, hist


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", default=str(DEFAULT_MLP_SVEIRS_RUN),
                    help="fitted MLP-SVEIRS run directory")
    ap.add_argument("--input-dir", default="data/processed/dataset_2010_2019")
    ap.add_argument("--out", default="morl/results/morl_demo")
    ap.add_argument("--iterations", type=int, default=500)
    ap.add_argument("--envs", type=int, default=12)
    ap.add_argument("--episode-weeks", type=int, default=481,
                    help="episode length in weeks")
    ap.add_argument("--weights", default="[[0.6,0.2,0.2]]",
                    help="JSON list of 3-objective preference vectors")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--lr", type=float, default=3e-4, help="PPO learning rate")
    ap.add_argument("--entropy", type=float, default=0.02,
                    help="entropy bonus coefficient")
    ap.add_argument("--lambda-cost", type=float, default=None,
                    help="override EnvConfig.lambda_cost")
    ap.add_argument("--lambda-diss", type=float, default=None,
                    help="override EnvConfig.lambda_diss")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device("cpu")

    model, _, data, batch = load_fitted(args.run_dir, args.input_dir, device)
    extra = {}
    if args.lambda_cost is not None:
        extra["lambda_cost"] = args.lambda_cost
    if args.lambda_diss is not None:
        extra["lambda_diss"] = args.lambda_diss
    env_cfg = EnvConfig(episode_weeks=args.episode_weeks, **extra)
    scenario = build_scenarios(model, data, batch, env_cfg,
                               n_envs=args.envs, device=device)
    env = VecSVEIHRSEnv(scenario, env_cfg)
    print(f"env: N={env.N} R={env.R} T={env.T} obs_dim={env.obs_dim}")
    print(f"  lambda_cost={env_cfg.lambda_cost:g} lambda_diss={env_cfg.lambda_diss:g}")
    print(f"  vaccine waning eta={env.eta:g}/wk (mean protection {1.0 / env.eta:.1f} wk)")
    print(f"  dose tiers={env_cfg.dose_level_frac} prices={env_cfg.dose_level_price}")
    print(f"  baseline no-intervention={[round(float(x), 4) for x in env.baseline_none[0]]} "
          f"full={[round(float(x), 4) for x in env.baseline_full[0]]}")

    weights_list = json.loads(args.weights)

    pcfg = PPOConfig(
        total_iterations=args.iterations,
        seed=args.seed,
        lr=args.lr,
        entropy_coef=args.entropy,
        n_levels=env_cfg.n_levels,
        n_dose_levels=env_cfg.n_dose_levels,
    )
    results = []
    for i, w in enumerate(weights_list):
        t0 = time.time()
        print(f"[{i + 1}/{len(weights_list)}] weights={w}")
        weights = torch.tensor(w, device=env.device, dtype=env.dtype)
        # Reward scale.
        episode_scale = float(max(abs(env.baseline_none[0] @ weights),
                                  abs(env.baseline_full[0] @ weights), 1.0))
        reward_scale = episode_scale / max(1, env.T)
        pcfg_i = PPOConfig(**{**pcfg.__dict__, "seed": args.seed + i})
        policy, J, C, traj, hist = train_one(
            env, weights, pcfg_i, reward_scale=reward_scale)
        print(f"    reward_scale={reward_scale:.4g}")
        tag = f"w{'_'.join(str(round(x, 2)) for x in w)}"
        torch.save(policy.state_dict(), out / f"policy_{tag}.pt")
        np.savez_compressed(out / f"trajectory_{tag}.npz", **traj,
                            weights=np.asarray(w), J_raw=J.cpu().numpy(),
                            cost=C.cpu().numpy())
        results.append({
            "tag": tag,
            "weights": list(w),
            "J_raw": [float(x) for x in J.mean(0)],
            "cost": [float(x) for x in C.mean(0)],
            "seconds": time.time() - t0,
            "history": hist,
            "final_iter": pcfg_i.total_iterations,
        })
        print(f"    J_raw={[round(float(x), 4) for x in J.mean(0)]}")

    meta_out = {
        "run_dir": relative_to_project(args.run_dir),
        "checkpoint": "model_final.pt",
        "episode_weeks": args.episode_weeks,
        "iterations": args.iterations,
        "envs": args.envs,
        "seed": args.seed,
        "baseline_none": [float(x) for x in env.baseline_none[0]],
        "baseline_full": [float(x) for x in env.baseline_full[0]],
        "d_max_per_capita": env_cfg.d_max_per_capita,
        "lambda_cost": env_cfg.lambda_cost,
        "lambda_diss": env_cfg.lambda_diss,
        "entropy_coef": args.entropy,
        "policy_selection": "last iteration",
        "observation_history": env.obs_history,
        "env_config": asdict(env_cfg),
    }
    (out / "results.json").write_text(
        json.dumps({**meta_out, "results": results}, indent=2))
    print(f"\nwrote {out}/results.json  ({len(results)} preference vectors)")


if __name__ == "__main__":
    main()
