"""Re-evaluate saved policies."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from .core.env import EnvConfig, VecSVEIHRSEnv, build_scenarios, load_fitted
from .core.ppo import ActorCritic, NullPolicy, PPOConfig, evaluate_policy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="morl/results/morl_demo")
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--input-dir", default="data/processed/dataset_2010_2019")
    args = ap.parse_args()

    out = Path(args.out)
    blob = json.loads((out / "results.json").read_text())
    run_dir = args.run_dir or blob["run_dir"]
    device = torch.device("cpu")

    model, _, data, batch = load_fitted(run_dir, args.input_dir, device)
    cfg = EnvConfig(**blob["env_config"])
    scenario = build_scenarios(model, data, batch, cfg, n_envs=blob["envs"], device=device)
    env = VecSVEIHRSEnv(scenario, cfg)
    pcfg = PPOConfig(n_dose_levels=cfg.n_dose_levels)

    for r in blob["results"]:
        policy = ActorCritic(env.R, env.obs_dim, pcfg)
        policy.load_state_dict(torch.load(out / f"policy_{r['tag']}.pt", map_location=device))
        J, C, traj = evaluate_policy(policy, env)
        np.savez_compressed(out / f"trajectory_{r['tag']}.npz", **traj,
                            weights=np.asarray(r["weights"]), J_raw=J.cpu().numpy(),
                            cost=C.cpu().numpy())
        print(f"  {r['tag']}: J_raw={[round(float(x), 3) for x in J.mean(0)]}")

    # No-intervention baseline.
    null = NullPolicy(env.N, env.R, device, env.dtype)
    J, C, traj = evaluate_policy(null, env)
    np.savez_compressed(out / "trajectory_baseline_none.npz", **traj,
                        weights=np.asarray([1 / 3, 1 / 3, 1 / 3]), J_raw=J.cpu().numpy(),
                        cost=C.cpu().numpy())
    print(f"  baseline-none: J_raw={[round(float(x), 1) for x in J.mean(0)]}")
    print(f"rewrote {len(blob['results'])} trajectories + 1 baseline in {out}")


if __name__ == "__main__":
    main()
