# MLP-SVEIRS + multi-objective RL for influenza policy

It contains the two algorithmic components:

- a multi-patch **MLP-SVEIRS** model whose network learns the time-varying
  transmission, vaccination and hospitalisation fields `beta(t)`, `psi(t)` and
  `h(t)` while the compartment trajectory is integrated mechanistically;
- a batched counterfactual epidemic environment and **multi-objective PPO** for
  isolation, masking and vaccination decisions.

## Layout

```text
mlp_sveirs/            MLP-SVEIRS model, dynamics, loss, checkpoint loader
  cli/train_ode.py     training entry point
morl/                  multi-objective RL package
  core/env.py          counterfactual SVEIHRS environment
  core/ppo.py          actor-critic, rollout and PPO update
  train_morl.py        RL training entry point
  reeval_policies.py   deterministic policy re-evaluation
data/README.md         expected preprocessed-data schema
```

## Install

Python 3.10+ is required. The release was tested with Python 3.10.1, PyTorch
2.2.2, torchdiffeq 0.2.5 and NumPy 1.26.4.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Data

Place `mlp_sveirs_input.npz` and `migration_matrices.npz` in
`data/processed/dataset_2010_2019/`. The required arrays are documented in
[`data/README.md`](data/README.md). Data and weights are distributed separately
from the code, as described in the paper's Data Availability statement.

## Train MLP-SVEIRS

```bash
# Full paper setting
python -m mlp_sveirs.cli.train_ode 5000 ode_generative
```

The run is written to `mlp_sveirs/results/<run_name>/` and contains
`arch.json`, `config.json` and the final-iteration weights `model_final.pt`.
Set `ODE_INPUT_DIR` to select another processed dataset and `ODE_THREADS` to
control CPU threading.

## Train multi-objective PPO

```bash
# Full-horizon setting: run once for each preference vector
python -m morl.train_morl \
  --run-dir mlp_sveirs/results/ode_generative \
  --episode-weeks 481 --iterations 500 --envs 12 \
  --entropy 0.02 \
  --weights '[[0.6,0.2,0.2]]' \
  --out morl/results/morl_w0.6_0.2_0.2
```

The four preference vectors used in the paper are
`[0.6,0.2,0.2]`, `[0.2,0.6,0.2]`, `[0.2,0.2,0.6]` and
`[1/3,1/3,1/3]`. The 2023-2025 fit uses `--episode-weeks 81`, with the matching
checkpoint and dataset and the `lambda_cost` / `lambda_diss` values calibrated
for that run.

## Citation and license

Add the paper citation, author list, repository DOI and license chosen by the
authors before publishing the archive.
