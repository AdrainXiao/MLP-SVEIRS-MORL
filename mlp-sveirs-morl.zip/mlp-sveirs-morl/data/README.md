# Input data

The code release does not redistribute the surveillance data or trained
weights. Place the preprocessed dataset referenced in the paper under:

```text
data/processed/dataset_2010_2019/
  mlp_sveirs_input.npz
  migration_matrices.npz
```

`mlp_sveirs_input.npz` contains arrays indexed by time `T` and region `R`:

- index and metadata: `states [R]`, `years [T]`, `weeks [T]`,
  `time_week [T]`, `population [T,R]`
- ILI: `ili_count`, `ili_input_count`, `ili_input_log1p`,
  `ili_observed_mask`, `ili_cumulative_count`
- hospital: `hospital_count_proxy`, `hospital_input_count`,
  `hospital_input_log1p`, `hospital_input_mask`
- vaccination: `vaccine_coverage`, `vaccine_weekly_count`,
  `vaccine_weekly_mask`, and `vaccine_coverage_imputed_mask`

All observation arrays use shape `[T,R]`; index arrays use `[T]` or `[R]`.

`migration_matrices.npz` must contain `migration_years [Y]` and
`M_directed_daily [Y,R,R]`, where row `i`, column `j` is the daily fraction
moving from source region `j` to destination `i`.

The dataset used in the paper is available from the paper's Data Availability
statement. If you use another processed dataset, pass its directory explicitly
through `--input-dir` (RL) or `ODE_INPUT_DIR` (MLP-SVEIRS).
